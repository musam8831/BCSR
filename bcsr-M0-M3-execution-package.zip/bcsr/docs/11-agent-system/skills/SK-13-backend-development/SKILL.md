---
name: backend-development
description: Build the optional research ingestion service and the catalogue build/sign pipeline; use for M4–M5 backend and scripts tasks.
---

# SK-13 · backend-development

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Provide minimal, secure server-side pieces without making the app dependent on them.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. Catalogue pipeline: validate → filter approved → bundle → sign (Ed25519) → publish artefact.
2. Ingestion API per api-contracts §3: TLS only, schema-validated, pseudonymous IDs, no PII fields.
3. Infrastructure as code; secrets in a vault, never in the repo.
4. Write an OpenAPI spec and contract tests.

## Outputs
- `app/backend/**`
- `scripts/catalogue/**`

## Quality checklist
- [ ] App works with the backend down
- [ ] AG-09 review passed
- [ ] Signing key never in the repo

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
