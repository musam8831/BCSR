---
name: research-synthesis
description: Conduct and synthesise literature and technology research with citations and licence checks; use for scientific-evidence, open-source evaluation and dataset research.
---

# SK-04 · research-synthesis

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Ground design choices in evidence and in legally usable open-source components.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. Turn the research question into search terms; log the queries.
2. Prefer peer-reviewed sources and systematic reviews; record DOI, population, method, effect and quality for each.
3. Never state a finding without a citation; mark weak evidence as weak.
4. For software, models, datasets and content sources: record the licence, version, commercial-use terms and attribution duties in the licence register.
5. Write implications for design as testable hypotheses (feed to AG-07).

## Outputs
- `docs/02-research/*`

## Quality checklist
- [ ] Every claim cited
- [ ] Licences verified from the primary licence text
- [ ] Limitations stated

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
