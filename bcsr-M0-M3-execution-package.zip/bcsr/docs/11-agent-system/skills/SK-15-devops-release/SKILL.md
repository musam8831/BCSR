---
name: devops-release
description: Set up CI/CD, code quality gates, signing, SBOM and Play release tracks; use from M3 onward.
---

# SK-15 · devops-release

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Make every change built, checked and releasable automatically and securely.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. GitHub Actions: build, lint, unit tests, schema validation of the content catalogue, docs link check, traceability check.
2. Dependency pinning, Gradle verification metadata, Dependabot, SBOM (CycloneDX).
3. Release signing via Play App Signing; secrets in GitHub encrypted secrets.
4. Release tracks: internal → closed pilot → production, each with a gate checklist.
5. Release notes from CHANGELOG.

## Outputs
- `.github/workflows/*`
- `docs/09-release-operations/*`

## Quality checklist
- [ ] Main branch protected
- [ ] CI required for merge
- [ ] No secrets in logs

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
