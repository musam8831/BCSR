---
name: qa-testing
description: Plan and execute testing for BCSR (test strategy, cases from acceptance criteria, automation, device matrix, safety and privacy tests); use from M2 onward.
---

# SK-14 · qa-testing

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Prove that each requirement works, and catch regressions early.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. Write a test strategy: levels, tools, device matrix, entry/exit criteria.
2. Derive test cases from every AC; link them in the traceability matrix.
3. Automate: unit, property tests (e.g., approved-only, AC-FR-15), instrumented tests, screenshot tests for RTL.
4. Run battery/latency benchmarks on reference devices.
5. Execute safety tests (AG-10) and privacy tests (AG-09: manifest, traffic capture).

## Outputs
- `docs/08-testing/*`
- `tests/**`

## Quality checklist
- [ ] Every Must requirement has a passing test
- [ ] Defects logged with severity
- [ ] Exit criteria evidenced

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
