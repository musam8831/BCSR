---
name: sdlc-governance
description: Produce and maintain project governance artefacts (charter, scope, risks, decisions, gate packs); use for any M0 work or gate preparation.
---

# SK-01 · sdlc-governance

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Keep the project controlled: clear scope, visible risks, recorded decisions, gate-ready evidence.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. Draft or update charter/scope from Project Lead input; mark every unknown as an assumption with a validating task.
2. Maintain the risk register weekly: rescore L×I, add new risks from task reports, and escalate scores ≥ 15.
3. Record decisions in decision-log.md; create an ADR stub for architectural ones and hand it to AG-03.
4. Before each gate, assemble a gate pack: exit-criteria checklist, evidence links, open risks, recommendation (go / no-go / conditional).
5. Run a short retrospective at each milestone end; feed skill improvements to SK-00.

## Outputs
- `docs/00-governance/*`
- `gate packs in docs/10-project-management/gates/`

## Quality checklist
- [ ] Every objective is measurable
- [ ] Every risk has an owner and a mitigation
- [ ] Gate pack links evidence, not claims

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
