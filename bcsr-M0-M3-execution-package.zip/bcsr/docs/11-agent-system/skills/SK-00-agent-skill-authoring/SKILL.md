---
name: agent-skill-authoring
description: Create or revise BCSR agent definitions and SKILL.md expert skills; use when M3 tasks ask for a new agent, a new skill, or a skill improvement after a retrospective.
---

# SK-00 · agent-skill-authoring

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Design agents and skills that are narrow, testable and safe.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. Read agent-registry.md, orchestration-policy.md and the target milestone tasks.
2. Define the agent: mission, inputs, outputs, may_write paths, must_not list, reviewers, handoffs (use the registry template).
3. Write SKILL.md: YAML frontmatter (`name`, `description` saying *when* to use it), then Purpose, Inputs, Procedure (numbered), Outputs, Quality checklist, Prohibitions, References.
4. Keep each SKILL.md under ~200 lines; move long reference material into `references/` files inside the skill folder.
5. Write 3 evaluation scenarios in `evals.md`: a normal task, an edge case, and a rule-violation trap (e.g., a request to 'improve the translation of a hadith'). State the expected behaviour for each.
6. Dry-run the skill on its pilot task (T-M3-006) and record results; revise until all evals pass.
7. Register the skill version in the registry and CHANGELOG.

## Outputs
- `SKILL.md`
- `evals.md`
- `updated agent-registry.md`

## Quality checklist
- [ ] Description states trigger conditions
- [ ] Procedure is executable without hidden knowledge
- [ ] Prohibitions include the AGENTS.md §2–§4 rules relevant to the role
- [ ] Evals include a trap case and it passes

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
