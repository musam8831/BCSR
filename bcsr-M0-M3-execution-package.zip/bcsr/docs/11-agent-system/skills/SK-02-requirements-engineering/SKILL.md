---
name: requirements-engineering
description: Elicit, write, baseline and trace BCSR requirements (SRS per ISO/IEC/IEEE 29148, stories, acceptance criteria); use in M1 and for any change request.
---

# SK-02 · requirements-engineering

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Produce unambiguous, testable, traceable requirements that implementation agents can build without guessing.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. Start from the charter, scope, personas and the module list in SRS §3.
2. Write requirements as 'The system shall …', one behaviour each, with an ID, module, priority (MoSCoW), source and rationale.
3. Check each against INVEST (stories) and testability: if you cannot write an acceptance test, rewrite it.
4. Write Gherkin acceptance criteria for every Must requirement.
5. Update traceability-matrix.md: Req ↔ Story ↔ AC ↔ Design ↔ Task ↔ Test.
6. Flag conflicts (e.g., privacy vs feature) as HC-07 rather than resolving them silently.
7. After G1, change requirements only through approved HC-07 change requests; bump the SRS version.

## Outputs
- `docs/01-requirements/*`

## Quality checklist
- [ ] No vague words (fast, user-friendly) without a metric
- [ ] Every Must has an AC
- [ ] No requirement outside charter scope
- [ ] Religious-content requirements reference CR-*

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
