---
name: solution-architecture
description: Design BCSR architecture (C4 views, module boundaries, data flow, API contracts) and write ADRs; use in M2 and when reviewing designs.
---

# SK-03 · solution-architecture

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Produce an architecture that satisfies the NFRs (offline, privacy, battery, latency) and is easy for agents to implement module by module.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. Read the SRS (especially NFRs, PRs, SRs), feasibility spike results and the threat model.
2. Maintain C4 L1–L3 diagrams in Mermaid; keep the Gradle module table in sync.
3. For each significant choice, write an ADR with ≥ 2 options and explicit consequences.
4. Define Kotlin interfaces and data contracts before implementation tasks become Ready (HC-02).
5. Set budgets per module (latency, memory, battery) and assign them to tests.
6. Review implementation PRs for boundary violations.

## Outputs
- `docs/03-architecture/*`
- ADRs

## Quality checklist
- [ ] Each NFR maps to a design element
- [ ] No component sends raw behaviour data off the device
- [ ] Interfaces are versioned

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
