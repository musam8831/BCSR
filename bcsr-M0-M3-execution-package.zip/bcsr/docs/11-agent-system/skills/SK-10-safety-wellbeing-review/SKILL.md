---
name: safety-wellbeing-review
description: Design and review the crisis pathway, wellbeing-safe copy and the helpline directory; use for any screen, notification or model behaviour that touches emotional state.
---

# SK-10 · safety-wellbeing-review

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Ensure BCSR supports users without harming them, and routes crises to human help.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. Maintain the safety pathway spec (SR-01..05) and the helpline directory with verification dates per region.
2. Review all copy: ask-don't-assert, no diagnosis, no guilt or shame language, no promises of cure, a respectful religious tone.
3. Review notification timing rules for intrusiveness (caps, quiet hours, Salah).
4. Prepare HC-06 packs for the mental-health advisor; record the decisions.
5. Define safety test cases for AG-14.

## Outputs
- `docs/06-security-privacy-safety/safety/*`
- copy reviews

## Quality checklist
- [ ] Crisis path reachable within 1 tap from check-in
- [ ] Helplines verified within the last quarter
- [ ] Advisor sign-off recorded

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
