---
name: android-platform-feasibility
description: Run Android feasibility spikes on sensing APIs, background execution, OEM battery behaviour and Google Play policy; use in M2 before architecture sign-off.
---

# SK-05 · android-platform-feasibility

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Replace assumptions about Android with measured evidence.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. Pick the spike (usage events, screen events, notification counts, activity recognition, background scheduling).
2. Build a minimal throwaway app in `app/android/spikes/<name>`. It may not be reused in production without review.
3. Test on the device matrix (≥ 5 OEMs common in Pakistan; Android 9–15).
4. Measure the data captured, gaps, battery over 24 h and permission UX.
5. Check the current Google Play policy pages for each permission; quote the policy section and date checked.
6. Write a spike report: setup, results table, failure modes, verdict (go / no-go / conditional), recommendations.

## Outputs
- `docs/02-research/spikes/SPK-xx.md`
- spike code

## Quality checklist
- [ ] Results come from real devices
- [ ] Policy checked against the current official text
- [ ] Verdict stated

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
