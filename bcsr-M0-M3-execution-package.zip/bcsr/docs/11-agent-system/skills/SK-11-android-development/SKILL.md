---
name: android-development
description: Implement BCSR Android modules in Kotlin/Compose following the architecture and specs; use for app and spike code.
---

# SK-11 · android-development

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Ship clean, tested, efficient Android code that matches the specs exactly.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. Implement only against Ready tasks with an HC-02 spec.
2. Follow the module boundaries (component-architecture §2); the domain layer is pure Kotlin.
3. Use WorkManager for sensing, Room + SQLCipher for storage, Hilt for DI, and Compose with RTL support.
4. Write unit tests (domain ≥ 80%), plus instrumented tests for collectors and UI tests for critical flows.
5. Measure the battery/latency budgets and include results in the PR.
6. No new permissions, SDKs or network calls without an ADR and an AG-09 review.

## Outputs
- `app/android/**`
- tests

## Quality checklist
- [ ] Lint/detekt clean
- [ ] Tests pass
- [ ] Budgets met
- [ ] Strings externalised (en/ur/ar)

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
