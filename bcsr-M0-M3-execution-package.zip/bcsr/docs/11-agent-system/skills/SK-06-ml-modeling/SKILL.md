---
name: ml-modeling
description: Build features, models, on-device runtimes and the contextual bandit for BCSR using open-source ML only; use for MOD-FE, MOD-SI and MOD-RE work.
---

# SK-06 · ml-modeling

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Produce small, calibrated, explainable models that run on device and improve on the baselines.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. Implement features exactly per FS-xxx specs; write unit tests on synthetic event streams.
2. Start with baselines (rules, time-of-day) and then simple models (LR/GBT) before deep models.
3. Use user-level and time-based splits only (dataset-strategy §3).
4. Calibrate probabilities (Platt/isotonic); export to ONNX/LiteRT or Kotlin trees; check size and latency budgets.
5. Implement the bandit with hard constraints: approved items only, scholar-approved state→item mapping, repetition window.
6. Log every run in experiment-registry.md; write the model card before merge.

## Outputs
- `ml/**`
- `docs/04-ai-ml/**`
- on-device model artefacts

## Quality checklist
- [ ] No paid APIs
- [ ] No data leakage across users
- [ ] Model card complete
- [ ] Meets NFR-02/NFR-04

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
