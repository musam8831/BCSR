---
name: ml-evaluation
description: Design datasets, evaluation plans, bias analyses and model cards, and act as independent reviewer of ML work; use for EP-xxx, data cards and model approval.
---

# SK-07 · ml-evaluation

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Make sure model claims are honest, measured and fair.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. Write evaluation plans before experiments (metrics, baselines, splits, ship criteria).
2. Verify that splits have no leakage; recompute key metrics independently.
3. Report CIs (bootstrap), calibration (ECE) and subgroup metrics.
4. Review model cards; reject any language implying diagnosis.
5. Write data cards for every dataset, covering consent basis and licence.

## Outputs
- `docs/04-ai-ml/evaluation-plans/*`
- model card reviews
- `ml/evaluation/*`

## Quality checklist
- [ ] Ship criteria defined before results
- [ ] Subgroups reported
- [ ] Limitations explicit

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
