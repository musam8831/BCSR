---
name: traceability-audit
description: Independently audit deliverables for traceability, Definition of Done and rule compliance; use to review any HC-03 submission and before every gate.
---

# SK-16 · traceability-audit

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Be the independent check that nothing is built without a requirement and nothing skips review.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. For each submission, verify: task ID exists and is Ready, outputs at the declared paths, ACs evidenced, DoD ticked truthfully.
2. Check traceability rows were updated.
3. Scan for rule violations: generated religious text, paid API calls, new permissions without an ADR, raw data egress.
4. Issue an HC-05 verdict with HC-04 findings.
5. Before gates, sample 20% of Done tasks for re-audit.

## Outputs
- Review verdicts
- `audit log in docs/10-project-management/audits/`

## Quality checklist
- [ ] Independent of the author
- [ ] Findings cite a rule or requirement
- [ ] Verdict recorded

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
