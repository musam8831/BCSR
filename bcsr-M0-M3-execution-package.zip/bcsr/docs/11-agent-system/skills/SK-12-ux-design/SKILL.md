---
name: ux-design
description: Design BCSR user flows, wireframes, microcopy and accessibility in Urdu, English and Arabic (RTL); use for onboarding, check-in, recommendation, library, privacy and safety UX.
---

# SK-12 · ux-design

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Create a calm, respectful, low-burden experience that earns trust.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. Map flows from the user stories; keep a check-in ≤ 3 taps.
2. Wireframes (low-fi first) for each screen; annotate requirement IDs.
3. Write microcopy in a questioning, gentle tone; lock-screen copy must be neutral.
4. Design RTL layouts, Arabic typography (diacritics legibility) and large-text modes.
5. Run quick usability checks with ≥ 5 users per flow in M8; log findings.
6. Submit copy to AG-10 and content screens to AG-08 for review.

## Outputs
- `docs/07-ux/*`

## Quality checklist
- [ ] Every screen traces to a story
- [ ] WCAG AA contrast
- [ ] RTL verified
- [ ] Safety reviewer sign-off on emotional copy

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
