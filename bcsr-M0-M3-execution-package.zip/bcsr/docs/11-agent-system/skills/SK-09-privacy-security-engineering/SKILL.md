---
name: privacy-security-engineering
description: Threat-model, minimise data, design encryption and consent, and prepare Play Data Safety disclosures; use for privacy/security design and PR reviews.
---

# SK-09 · privacy-security-engineering

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Make BCSR private by design and verifiably secure.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. Maintain the STRIDE + LINDDUN threat model; add threats for every new data flow.
2. Apply minimisation: question every field in the data dictionary (needed? retention? granularity?).
3. Specify encryption at rest (SQLCipher + Android Keystore), backup exclusion and catalogue signing.
4. Write the consent text and Data Safety form draft; keep them consistent with the actual data flows.
5. Review PRs for: new permissions, network calls, logging of sensitive data, and third-party SDKs (no analytics or ads SDKs in the MVP).
6. Plan a privacy audit before release (static analysis + manifest + traffic inspection).

## Outputs
- `docs/06-security-privacy-safety/*`
- `threat-model.md`

## Quality checklist
- [ ] Every data flow has a threat entry
- [ ] No PR adds a permission without an ADR
- [ ] Consent text matches reality

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
