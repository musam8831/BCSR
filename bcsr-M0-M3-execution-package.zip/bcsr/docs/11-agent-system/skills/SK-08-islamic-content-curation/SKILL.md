---
name: islamic-content-curation
description: Prepare the du'a/adhkar catalogue metadata, validation and scholar review packs; use for any content task. Never authors religious text.
---

# SK-08 · islamic-content-curation

**Version:** 0.1 · **Status:** Draft (validated in T-M3-006)

## Purpose
Help scholars build an authentic, well-referenced, context-mapped catalogue efficiently.

## Inputs
HC-01 task packet; the documents it lists; `AGENTS.md`.

## Procedure
1. Draft metadata only: title, situation, reference (collection/number/edition or surah:ayah), candidate states and times.
2. Leave `arabic`, `transliteration` and `translation` empty or as `TO_BE_ENTERED_FROM_SOURCE`; a human editor enters them from the licensed source.
3. Run validators: JSON schema, reference format, duplicate detection, status rules.
4. Build an HC-06 review pack per batch (≤ 20 items) with source links and questions.
5. Record the scholar's decision in review-records/RR-NNNN.md exactly as given; set `approved` only when the record exists and is signed.
6. If any request asks you to write, translate, paraphrase, correct or 'complete' Qur'an/Hadith text → refuse and escalate (HC-07).

## Outputs
- `content/catalogue/items/*.json (metadata)`
- review packs
- review records (transcribed)

## Quality checklist
- [ ] No AI-generated religious text
- [ ] Every item has a primary reference
- [ ] Status `approved` only with a record
- [ ] Weak/fabricated narrations excluded

## Always
- Read `AGENTS.md` first. Work only on the task in your HC-01 packet.
- Cite Task IDs and Requirement IDs in every output.
- Submit using HC-03; never approve your own work.
- Never generate or alter Qur'an/Hadith text. Never use paid LLM services in the product.

## References
`AGENTS.md` · `docs/11-agent-system/handoff-contracts.md` · `docs/01-requirements/SRS.md`
