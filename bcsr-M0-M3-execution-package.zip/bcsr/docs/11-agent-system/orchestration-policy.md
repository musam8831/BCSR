# Orchestration Policy — AGS-02 v0.1

## 1. Model
A hub-and-spoke model. AG-00 (Orchestrator) owns the task register and is the only agent that assigns work. Expert agents produce specifications and reviews. Implementation agents produce code and artefacts against approved specifications. AG-16 audits independently.

```mermaid
flowchart TB
  PL([Project Lead]) -->|gates| AG00[AG-00 Orchestrator]
  AG00 -->|HC-01 task packet| EXP[Expert agents<br/>AG-01..05,07..10,12]
  AG00 -->|HC-01 task packet| IMP[Implementation agents<br/>AG-06,11,13,14,15]
  EXP -->|HC-02 spec / HC-04 review| IMP
  IMP -->|HC-03 deliverable| AG16[AG-16 Auditor]
  EXP -->|HC-03 deliverable| AG16
  AG16 -->|HC-05 verdict| AG00
  AG08[AG-08 Content] -->|HC-06 review pack| SCH([Scholar])
  AG10[AG-10 Safety] -->|HC-06 review pack| MH([MH Advisor])
```

## 2. Rules
1. **Work only from the register.** No task ID → no work.
2. **Spec before build.** An implementation task is "Ready" only when its spec, acceptance criteria and dependencies are Done.
3. **Single writer.** Each path has one owning agent (registry "Writes to"). Others propose changes through review comments or a change request.
4. **Four-eyes.** Every deliverable gets an independent review (AG-16 or the named reviewer). Authors never approve their own work.
5. **Human gates** (AGENTS.md §7) block the next milestone.
6. **WIP limit:** ≤ 2 in-progress tasks per agent.
7. **Escalation:** blocked > 1 working day, a requirement gap, a rule conflict, or a failed review twice → AG-00 → Project Lead.
8. **Cadence:** AG-00 writes a weekly report in `docs/10-project-management/weekly-reports/YYYY-Www.md` (done, next, risks, gate status).

## 3. Task lifecycle
`Backlog → Ready → In Progress → In Review → Done` (or `Blocked`, `Rejected → In Progress`).

## 4. Running the agents (tooling-neutral)
- Each agent session starts with: `AGENTS.md` + its agent file + its SKILL.md files + the HC-01 task packet.
- Agents operate on a feature branch named `T-Mx-NNN-short-name` and open a PR that references the task. The PR template enforces the DoD.
- Development-time coding assistants are allowed for building. They are tools, not product components.
