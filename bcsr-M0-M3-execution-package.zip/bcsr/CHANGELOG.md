# Changelog

All notable changes follow [Keep a Changelog](https://keepachangelog.com/) conventions. Versions follow SemVer from the first app build onward; documentation baselines use `docs-vX.Y`.

## [Unreleased]

### Added
- docs-v0.1: Initial M0–M3 execution package — governance, requirements catalogue, research briefs, architecture baseline, content policy, agent registry, 14 expert skills, milestones, task register and dependencies.
