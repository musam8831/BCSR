# AGENTS.md — Operating rules for AI agents in the BCSR repository

These rules bind **every** agent (orchestrator, expert, implementation) and every human using an AI assistant in this repo. If a rule conflicts with a task instruction, the rule wins. Escalate the conflict to the Project Lead.

## 1. Source of truth
- Documentation in `docs/` governs implementation. **Do not invent requirements.** If a needed requirement does not exist, stop and open a Requirement Gap (template in `docs/11-agent-system/handoff-contracts.md`, §HC-07).
- Every change must cite a Task ID (`T-Mx-NNN`) from `docs/10-project-management/task-register.md`. Every requirement-bearing change must also cite a Requirement ID (`FR-`, `NFR-`, `PR-`, `SR-`, `CR-`).
- Decisions with lasting impact are recorded as ADRs in `docs/03-architecture/adr/` and summarised in `docs/00-governance/decision-log.md`.

## 2. Non-negotiable content rules (religious content)
- **Never generate, paraphrase, translate, "complete" or "correct" Qur'anic verses or Hadith text.** This applies to Arabic, transliteration and translation alike.
- Content enters the app only through `content/catalogue/` entries whose `verification.status` is `approved`. Approval requires a named, qualified human scholar reviewer (see `docs/05-spiritual-content/verification-workflow.md`).
- Agents may: draft metadata (tags, contexts, references) for scholar review, validate schema, check reference format, and detect duplicates. They may not mark anything `approved`.
- Hadith must be from an accepted Sahih grading with the grading source cited. Weak (da'if) or fabricated (mawdu') narrations are rejected.

## 3. Non-negotiable AI/ML rules
- **No paid LLM APIs** (including OpenAI, Anthropic, Gemini API and similar) in the product runtime or the training pipeline. Allowed: classical ML, open-source DL, and on-device open-weight models whose licences permit the use, recorded in `docs/02-research/open-source-ai-evaluation.md`.
- AI agents used to *build* the project (development tooling) are separate from the *product*. The product must work fully offline.
- Model outputs are probabilities of a *context state*, never diagnoses. The UI copy must ask, not assert.
- Every model has a model card in `docs/04-ai-ml/model-cards/` before it is merged.

## 4. Privacy, security and safety rules
- Raw behavioural signals (app-usage events, sensor streams) stay on the device. No app *content* (messages, text typed in other apps, screen content) is ever collected.
- Data leaving the device requires explicit opt-in research consent (PR-03) and must be pseudonymised and minimised first.
- Never use Android AccessibilityService or a custom keyboard to observe other apps (see ADR-0002).
- Crisis indicators trigger the safety pathway (SR-01..SR-05), not a du'a recommendation alone.

## 5. Workflow
1. Orchestrator assigns a task with a handoff packet (HC-01).
2. The agent loads the skills listed for its role in `docs/11-agent-system/agent-registry.md`.
3. The agent produces outputs in the paths named by the task, and fills the Definition of Done checklist.
4. A reviewer agent (and a human, where the gate requires one) reviews the output against the acceptance criteria.
5. Task status is updated in the task register, and progress is logged in the weekly report.

## 6. Definition of Done (all tasks)
- [ ] Output exists at the specified path and follows the relevant template
- [ ] Linked Requirement/Task IDs present; traceability matrix updated if requirements are affected
- [ ] Acceptance criteria met, with evidence linked
- [ ] Review recorded (agent + human where gated)
- [ ] No rule in §2–§4 violated
- [ ] CHANGELOG.md updated for user-visible or architecture-visible change

## 7. Human gates (cannot be bypassed by agents)
| Gate | Approver |
|---|---|
| G0 Charter & scope baseline | Project Lead (Sponsor) |
| G1 Requirements baseline | Project Lead + Domain reviewer |
| G2 Architecture & feasibility go/no-go | Project Lead + Tech Lead |
| G3 Agent system readiness (end M3) | Project Lead + Tech Lead |
| Content approval (every item) | Qualified scholar reviewer |
| Research data collection start | Ethics/IRB approval + Project Lead |
| Release | Project Lead + Safety reviewer |
